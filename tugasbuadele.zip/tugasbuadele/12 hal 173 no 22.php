<?php
    for ($i = 1; $i <= 20; $i++) {
        echo "Saya sedang belajar PHP <br>";
    }
?>