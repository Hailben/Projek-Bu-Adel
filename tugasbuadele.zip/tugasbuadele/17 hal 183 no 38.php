<?php
    $nama = array("Andri","Joko","Sukma","Rina","Sari");

    for ($i = 0; $i < 5;  $i++) {
        echo "$nama[$i] <br>";
    }
?>