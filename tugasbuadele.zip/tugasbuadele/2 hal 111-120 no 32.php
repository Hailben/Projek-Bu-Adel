<?php
    $siswa = array("Andri","Joko","Sukma","Rina","Sari");
    echo $siswa[1]; // Hoko
?>