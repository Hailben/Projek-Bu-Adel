<?php
    $siswa = array(
                    "satu" => "Andri",
                    "dua" => "Joko",
                    "tiga" => "Sukma",
                    "empat" => "Rina",
    );

    echo $siswa = ["dua"]; // Joko
    echo "<br>";
    echo $siswa["empat"]; // Rina
?>