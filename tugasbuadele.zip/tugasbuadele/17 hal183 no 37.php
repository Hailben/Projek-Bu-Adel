<?php
    $i = 1000;
    do {
        echo "$i ";
        echo "Akan tampil di brower<br>";
        $i = $i+1; 
    }   while ($i <= 10);
?>