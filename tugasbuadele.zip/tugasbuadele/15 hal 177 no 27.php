<?php
    for ($i = 1; $i <= 15; $i++) :
    echo "$i <br>";
    endfor;
?>