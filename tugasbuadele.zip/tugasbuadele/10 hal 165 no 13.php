<?php
    $hari = 4;
    switch ($hari) {
        case 1 : 
            echo "Hari Senin";
            break;
        case 2 : 
            echo "Hari Selasa";
            break;
        case 3 : 
            echo "Hari Rabu";
            break;
        case 4 : 
            echo "Hari Kamis";
            break;
        case 5 : 
            echo "Hari Jum'at";
            break;
        case 6 : 
            echo "Hari Sabtu";
            break;
        case 7 : 
            echo "Hari Minggu";
            break;
        dafault : 
            echo "Nama hari cuma ada 7!";
            break;
    }
?>