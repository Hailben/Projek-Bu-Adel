<?php
    function salam() {
        echo "<p>Selamat Pagi</p>";
    }

    salam(); // Selamat Pagi
?>