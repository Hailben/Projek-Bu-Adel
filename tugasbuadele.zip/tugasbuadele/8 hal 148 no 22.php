<?php
    $a = 10;
    $a += 5;
    echo $a; // 15
    echo "<br>";

    $a = 55;
    $a += 5;
    echo $a; // 11
    echo "<br>";

    $a = "Belajar";
    $a .= "PHP";
    echo $a; // Belajar PHP
?>