<?php
    $siswa = array("Andri","Joko","Sukma","Rina,","Sari");

    echo $siswa[2]; // Sukma
    echo "<br>";
    echo "Murid itu bersama $siswa [0]"; // Murid itu bernama Andri
?>